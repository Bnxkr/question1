import "./styles.css";
import CreditCard from "./CreditCard";
export default function App() {
  return (
    <div className="App">
      <CreditCard />
    </div>
  );
}
